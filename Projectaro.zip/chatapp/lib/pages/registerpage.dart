import 'package:chatapp/components/loginbutton.dart';
import 'package:chatapp/components/textfield.dart';
import 'package:flutter/material.dart';

class RegisterPage extends StatelessWidget {
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _confirmPwController = TextEditingController();
  final void Function()? onTap;
  RegisterPage({super.key, required this.onTap});

  void register() {}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.app_registration, size: 50),
            Text('Register Now', style: TextStyle(color: Colors.grey.shade600)),
            const SizedBox(height: 25),
            MyTextField(
              inHintText: "Email",
              obscText: false,
              conTroller: _emailController,
            ),
            const SizedBox(height: 10),
            MyTextField(
              inHintText: "Password",
              obscText: true,
              conTroller: _passwordController,
            ),
            const SizedBox(height: 10),
            MyTextField(
              inHintText: 'Confirm Password',
              obscText: true,
              conTroller: _confirmPwController,
            ),
            const SizedBox(height: 20),
            LoginButton(onTap: register, buttonName: 'Register'),
            const SizedBox(height: 25),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Already Have An Account',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                const SizedBox(width: 20),
                GestureDetector(
                  onTap: onTap,
                  child: Text(
                    'Login Now',
                    style: TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
